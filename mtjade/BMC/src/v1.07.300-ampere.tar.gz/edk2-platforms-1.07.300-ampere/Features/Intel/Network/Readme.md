# **EDK II Minimum Platform Firmware Network Features**

This feature domain directory contains network related advanced features.

Features may be added to this domain whose primary role and responsibility is related to network technologies.
