ASPEED AST2500 Evaluation Board
================

This is the ASPEED AST2500 evaluation board layer.
The AST2500 is an ARM, service management SOC made by ASPEED. More information
about the AST2500 can be found
[here](https://www.aspeedtech.com/products.php?fPath=20&rId=440).
