Convenience layer for building OpenBMC on ASPEED AST2600 EVB
================

This layer allows you to build OpenBMC for AST2600 EVB in the Aspeed BSP layer
without having to manually configure bblayers.conf and local.conf.

The AST2600 is an ARM, service management SOC made by ASPEED. More information
about the AST2600 can be found
[here](http://aspeedtech.com/server_ast2600/).
