Nuvoton NPCM750 Evaluation Board
================

This is the Nuvoton NPCM750 evaluation board layer.
The NPCM750 is an ARM based SoC with external DDR RAM and 
supports a large set of peripherals made by Nuvoton. 
More information about the NPCM7XX can be found
[here](http://www.nuvoton.com/hq/products/cloud-computing/ibmc/?__locale=en).